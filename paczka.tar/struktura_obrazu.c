#include <stdio.h>
/*inicjuje nowa strukture, st_obraz <nazwa struktury>         */
    /*void ze wzgledu na mozliwosc dynamicznego alokowania pamieci*/
    typedef struct {
        int wym_x,wym_y,odcieni;
        void *piksele;
    }st_obraz;

int main(){
    
}